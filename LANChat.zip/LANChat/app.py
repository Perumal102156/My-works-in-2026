
import os
import sys
import hmac
import sqlite3
import getpass
from pathlib import Path
from functools import wraps

from flask import (
    Flask, render_template, request, redirect,
    url_for, session, abort, g, flash
)
from flask_socketio import SocketIO, emit
from werkzeug.security import generate_password_hash, check_password_hash

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "chat.db"

secret_key = os.environ.get("FLASK_SECRET_KEY")
if not secret_key or len(secret_key) < 32:
    raise RuntimeError(
        "Set FLASK_SECRET_KEY to a persistent random secret of at least 32 characters."
    )

app = Flask(__name__)
app.config.update(
    SECRET_KEY=secret_key,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    # This prototype uses HTTP on your LAN. Use HTTPS before production.
    SESSION_COOKIE_SECURE=False,
    PERMANENT_SESSION_LIFETIME=1800,
    MAX_CONTENT_LENGTH=2 * 1024 * 1024,
)

socketio = SocketIO(app, async_mode="threading")


def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(error=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    with sqlite3.connect(DB_PATH) as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT UNIQUE NOT NULL COLLATE NOCASE,
                display_name TEXT NOT NULL,
                password_hash TEXT NOT NULL,
                role TEXT NOT NULL CHECK(role IN ('admin', 'user')),
                active INTEGER NOT NULL DEFAULT 1,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
        """)


def current_user():
    uid = session.get("uid")
    if not uid:
        return None

    return get_db().execute(
        "SELECT id, user_id, display_name, role, active "
        "FROM users WHERE id = ? AND active = 1",
        (uid,)
    ).fetchone()


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        user = current_user()
        if user is None:
            session.clear()
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        user = current_user()
        if user is None:
            session.clear()
            return redirect(url_for("login"))
        if user["role"] != "admin":
            abort(403)
        return view(*args, **kwargs)
    return wrapped


def csrf_token():
    import secrets
    if "csrf_token" not in session:
        session["csrf_token"] = secrets.token_urlsafe(32)
    return session["csrf_token"]


app.jinja_env.globals["csrf_token"] = csrf_token


def valid_csrf():
    submitted = request.form.get("csrf_token", "")
    expected = session.get("csrf_token", "")
    return bool(expected and submitted and hmac.compare_digest(submitted, expected))


@app.route("/", methods=["GET"])
def home():
    if current_user():
        return redirect(url_for("chat"))
    return redirect(url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        if not valid_csrf():
            abort(400, "Invalid form token. Refresh the page and try again.")

        user_id = request.form.get("user_id", "").strip()
        password = request.form.get("password", "")

        user = get_db().execute(
            "SELECT * FROM users WHERE user_id = ?",
            (user_id,)
        ).fetchone()

        # Do not reveal whether the user ID exists.
        if user and user["active"] and check_password_hash(
            user["password_hash"], password
        ):
            session.clear()
            session["uid"] = user["id"]
            session.permanent = True
            return redirect(url_for("chat"))

        flash("Invalid user ID or password, or account disabled.")

    return render_template("login.html")


@app.route("/logout", methods=["POST"])
@login_required
def logout():
    if not valid_csrf():
        abort(400, "Invalid form token.")
    session.clear()
    return redirect(url_for("login"))


@app.route("/chat")
@login_required
def chat():
    user = current_user()
    return render_template("Chat.html", user=user)


@app.route("/admin", methods=["GET", "POST"])
@admin_required
def admin():
    db = get_db()

    if request.method == "POST":
        if not valid_csrf():
            abort(400, "Invalid form token.")

        action = request.form.get("action", "")

        if action == "create":
            user_id = request.form.get("user_id", "").strip()
            display_name = request.form.get("display_name", "").strip()
            password = request.form.get("password", "")
            role = request.form.get("role", "user")

            if (
                not user_id or len(user_id) > 50
                or not display_name or len(display_name) > 100
                or len(password) < 6
                or role not in ("admin", "user")
            ):
                flash("Check the fields. Passwords must be at least 12 characters.")
            else:
                try:
                    db.execute(
                        "INSERT INTO users "
                        "(user_id, display_name, password_hash, role) "
                        "VALUES (?, ?, ?, ?)",
                        (
                            user_id, display_name,
                            generate_password_hash(password), role
                        )
                    )
                    db.commit()
                    flash("User account created.")
                except sqlite3.IntegrityError:
                    flash("That user ID already exists.")

        elif action == "toggle":
            try:
                target_id = int(request.form.get("target_id", ""))
            except ValueError:
                abort(400)

            target = db.execute(
                "SELECT id, role, active FROM users WHERE id = ?",
                (target_id,)
            ).fetchone()

            if target is None:
                abort(404)
            elif target["id"] == session["uid"]:
                flash("You cannot disable your own account.")
            elif target["role"] == "admin" and target["active"]:
                active_admins = db.execute(
                    "SELECT COUNT(*) FROM users "
                    "WHERE role = 'admin' AND active = 1"
                ).fetchone()[0]
                if active_admins <= 1:
                    flash("You cannot disable the last active administrator.")
                else:
                    db.execute(
                        "UPDATE users SET active = 0 WHERE id = ?",
                        (target_id,)
                    )
                    db.commit()
                    flash("Account disabled.")
            else:
                db.execute(
                    "UPDATE users SET active = ? WHERE id = ?",
                    (0 if target["active"] else 1, target_id)
                )
                db.commit()
                flash("Account status updated.")

        return redirect(url_for("admin"))

    users = db.execute(
        "SELECT id, user_id, display_name, role, active, created_at "
        "FROM users ORDER BY id"
    ).fetchall()

    return render_template("admin.html", users=users)


@socketio.on("connect")
def socket_connect(auth=None):
    user = current_user()
    if user is None:
        return False


@socketio.on("send_message")
def send_message(data):
    user = current_user()
    if user is None:
        return False

    if not isinstance(data, dict):
        return

    message = data.get("message", "")
    if not isinstance(message, str):
        return

    message = message.strip()
    if not message:
        return

    if len(message) > 2000:
        emit("chat_error", {"message": "Message is too long."})
        return

    # Sender identity comes from the authenticated server session,
    # never from a username supplied by the browser.
    emit("receive_message", {
        "user": user["display_name"],
        "user_id": user["user_id"],
        "message": message
    }, broadcast=True)


def create_admin():
    init_db()
    print("Create the first administrator account.")
    user_id = input("Admin user ID: ").strip()
    display_name = input("Admin display name: ").strip()
    password = getpass.getpass("Admin password (minimum 12 characters): ")
    confirm = getpass.getpass("Confirm password: ")

    if not user_id or len(user_id) > 50 or not display_name or len(display_name) > 100:
        print("Invalid user ID or display name.")
        return

    if len(password) < 12 or password != confirm:
        print("Passwords must match and contain at least 12 characters.")
        return

    try:
        with sqlite3.connect(DB_PATH) as db:
            db.execute(
                "INSERT INTO users "
                "(user_id, display_name, password_hash, role) "
                "VALUES (?, ?, ?, 'admin')",
                (user_id, display_name, generate_password_hash(password))
            )
        print("Administrator created successfully.")
    except sqlite3.IntegrityError:
        print("That user ID already exists.")


if __name__ == "__main__":
    init_db()

    if len(sys.argv) > 1 and sys.argv[1] == "create-admin":
        create_admin()
    else:
        socketio.run(app, host="0.0.0.0", port=5000, debug=False)
